import React from "react";
import CartContext from "./cart-context";
// CartContext = cart-context.js 안의 4가지 데이터 (초기화)

const CartProvider = (props) => {
  // 함수 정의
  const addItemToCartHandler = (item) => {};
  const removeItemFromCartHandler = (id) => {};

  // 업데이트 될 객체 - 다이나믹하게 변하는 부분(게속 변하는 부분)
  const cartContext = {
    items: [], // 아이템이 들어있는 배열
    totalAmount: 0, // 총 금액
    addItem: addItemToCartHandler,
    removeItem: removeItemFromCartHandler
  };

  return (
    <CartContext.Provider value={cartContext}>
      {props.children}
    </CartContext.Provider>
  );
};

export default CartProvider;
